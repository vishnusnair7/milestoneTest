let collapseContent = document.getElementById("mypara");
let plusicn = document.getElementById("plusIcon");
let minusicn = document.getElementById("minusIcon");

let collapseContent2 = document.getElementById("mypara2");
let plusicn2 = document.getElementById("plusIcon2");
let minusicn2 = document.getElementById("minusIcon2");

minusicn.onclick = function() {
    collapseContent.classList.toggle("d-none");
    plusicn.classList.toggle("d-none");
    minusicn.classList.toggle("d-none");

};
plusicn.onclick = function() {
    collapseContent.classList.toggle("d-none");
    plusicn.classList.toggle("d-none");
    minusicn.classList.toggle("d-none");

};
minusicn2.onclick = function() {
    collapseContent2.classList.toggle("d-none");
    plusicn2.classList.toggle("d-none");
    minusicn2.classList.toggle("d-none");

};
plusicn2.onclick = function() {
    collapseContent2.classList.toggle("d-none");
    plusicn2.classList.toggle("d-none");
    minusicn2.classList.toggle("d-none");

};